/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sinif.dene;

public class sayi {

    public static double uret() {
        return Math.random();
    }
    
    public static String goster(){
        double num = Math.random();
        if(num>0.65){
            return "<h2>Sansli gunun!</h2><p>"+ num +"</p>";
        }
        else{
            return "<h2>Hayat devam ediyor ... </h2><p>" +num+ "</p>";
        }
    }
}
