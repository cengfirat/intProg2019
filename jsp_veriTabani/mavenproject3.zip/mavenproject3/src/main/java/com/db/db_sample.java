package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author ibrahim
 */
public class db_sample {

    public static void main(String[] args) {
        String connectionURL = "jdbc:derby://localhost:1527/dene1";

        try {
            Connection con = DriverManager.getConnection(connectionURL, "app", "app");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from CUSTOMER");
            
            if (rs.next()) {
                System.out.println("name : " + rs.getString(1));
                System.out.println("address : " + rs.getString(5));
                System.out.println("city : " + rs.getString("CITY"));

            } else {
                System.out.println("No such user id is already registered");
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
