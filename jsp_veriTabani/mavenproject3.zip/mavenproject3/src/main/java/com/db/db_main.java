package com.db;

import java.sql.*;

/**
 *
 * @author ibrahim
 */
public class db_main {

    public static void main(String[] args) {

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");// or may be it is "org.apache.derby.jdbc.EmbeddedDriver"? Not sure. Check the correct name and put it here.
        } catch (ClassNotFoundException e) {
            System.out.println("for name ----");
            e.printStackTrace();
            //handle exception
        }

        String data = "jdbc:derby://localhost:1527/dene1";
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            Connection conn = DriverManager.getConnection(data, "app", "app");
            Statement st = conn.createStatement();

            String query = "select CUSTOMER_ID, NAME, CITY, STATE "
                    + "from APP.CUSTOMER "
                    + "order by CUSTOMER_ID";
            ResultSet rec = st.executeQuery(query);

            while (rec.next()) {
                System.out.println("CUSTOMER_ID = " + rec.getString(1));
                System.out.println("NAME = " + rec.getString(2));

            }
            rec.close();

        } catch (SQLException s) {
            System.out.println("sql exception " + s.toString());
        } catch (Exception e) {
            System.out.println("error " + e.toString());
        }
    }

}
