/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.db;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author ibrahim
 */
public class test_connection {

    public static void main(String[] args) throws SQLException {

        String connectionURL = "jdbc:derby://localhost:1527/dene1";

        //ConnectionURL, username and password should be specified in getConnection()
        try {

            Connection conn = DriverManager.getConnection(connectionURL, "app1", "app");
            System.out.println("Connect successfully ! ");
            conn.close();
        } catch (SQLException ex) {
            System.out.println("Connect failed ! ");
            ex.printStackTrace();
        }
    }

}
