package com.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class dbweb {

    public String getTable() {

        String connectionURL = "jdbc:derby://localhost:1527/dene1";
        String sonuc = "";
        try {
            Connection con = DriverManager.getConnection(connectionURL, "app", "app");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from CUSTOMER");
            
            while (rs.next()) {
                sonuc += "<tr>";
                sonuc += "<td>" + rs.getString(4) + "</td>";
                sonuc += "<td>" + rs.getString(5) + "</td>";
                sonuc += "<td>" + rs.getString("CITY") + "</td>";
                sonuc += "</tr>";
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return sonuc;
    }

    public static void main(String[] args) {
        dbweb db = new dbweb();
        System.out.println(db.getTable());
    }

}
